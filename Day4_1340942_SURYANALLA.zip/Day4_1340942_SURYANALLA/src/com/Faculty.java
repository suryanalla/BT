package com;

public class Faculty 
{
	private int facultyid;
	private String name;
	private double salary;
	
	Faculty(int facultyid, String name, double salary)
	{
		this.facultyid = facultyid;
		this.name = name;
		this.salary = salary;
	}
	public int getFacultyId()
	{
		return facultyid;
	}
	public void setFacultyId(int facultyid)
	{
		this.facultyid = facultyid;
	}
	public String getName()
	{
		return name;
	}
	public void setName(String name)
	{
		this.name = name;
	}
	public double getSalary()
	{
		return salary;
	}
	public void setSalary(double salary)
	{
		this.salary = salary;
	}
	

}
