package com;

public class FacultyOperations
{
	public Faculty findFaculty(int x,Faculty faculty[])
	{
		for (Faculty f : faculty)
		{
		if (x.equals(f))
		{
			
		}
		}
	}
	public static boolean searchFaculty(String s, Faculty[] faculty)
	{
		for (Faculty f : faculty)
		{
			if(s.equals(f))
			{
				return true;
			}
				
		}
		return false;
	}
	
	
}
