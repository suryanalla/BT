package com;

public class Day4Diagnostics {

	public static void main(String[] args)
	{
		Faculty f[];
		f = new Faculty(1,"surya",23000);
		
		

	}

}
